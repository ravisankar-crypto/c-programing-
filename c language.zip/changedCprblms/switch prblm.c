#include <stdio.h>
int main()
{
	int choice;
	double r,l,b;
	
	printf("1.Area of rectangle\n");
	printf("2.Area of circle\n");
	printf("3.Area of square\n");
	printf("Enter your choice (1-3): ");
	scanf("%d",&choice);
	
	switch(choice){
		case 1:
			printf("Enter length and breadth: ");
			scanf("%lf%lf",&l,&b);
			printf("Result is : %lf",l*b);
			break;
		case 2:
			printf("Enter radius: ");
			scanf("%lf",&r);
			printf("Result is : %lf",3.14*r*r);
			break;
		case 3:
			printf("Enter side length : ");
			scanf("%lf",&l);
			printf("Result is : %lf",l*l);
			break;
		default:
			printf("Invalid choice..try again choosing from 1-3");		
	}
	return 0;
}