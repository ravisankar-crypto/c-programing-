#include <stdio.h>
int main()
{
	int a,b,c,d,e;
	scanf("%d%d%d%d%d",&a,&b,&c,&d,&e);
	printf("Sum is : %d\nAverage : %f",a+b+c+d+e,(float)a+b+c+d+e/5);
	return 0;
}