#include <stdio.h>
#include <string.h>
int main(){
	int a;
	printf("give a number:");
	scanf("%d",&a);
	if(a>=91 && a<=100){
	printf("grade is: A");
	}else if(a>60 and a<=91){
		printf("grade is:B");
	}else{
	printf("grade is:c");
	}
	
}