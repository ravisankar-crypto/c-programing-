#include <stdio.h>
int main()
{
	int a,sum=0,rem,i=0;
	scanf("%d",&a);
	while(a!=0){
		rem=a%10;
		sum+=rem;
		a=a/10;
	}
	printf("%d",sum);
	return 0;
}