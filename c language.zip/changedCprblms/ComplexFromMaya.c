//Basic Pattern 5.1
#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			printf("%d",&i);
		}
		for(int s=1;s<=n-i;s++){
			printf("*");
		}
		printf("\n");
	}
	return 0;
}

//Basic Pattern 5.2
#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			printf("%d",j);
		}
		for(int s=1;s<=n-i;s++){
			printf("*");
		}
		printf("\n");
	}
	return 0;
}

//Basic Pattern 5.3
#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=n;i>=1;i--){
		for(int j=1;j<=i;j++){
			printf("%d",i);
		}
		for(int s=1;s<=n-i;s++){
			printf("*");
		}
		printf("\n");
	}
	return 0;
}


//Basic Pattern 5.4
#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=n;i>=1;i--){
		for(int j=1;j<=i;j++){
			printf("%d",j);
		}
		for(int s=1;s<=n-i;s++){
			printf("*");
		}
		printf("\n");
	}
	return 0;
}


//Basic Pattern 6.1
#include <stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	for(int i=1;i<=n;i++){
		for(int j=1;j<=i;j++){
			printf("* ");
		}
		printf("\n");
	}
	return 0;
}


//Basic Pattern 6.2