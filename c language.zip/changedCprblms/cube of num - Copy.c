#include<stdio.h>
int main()
{
	int num;
	printf("Enter a number : ");
	scanf("%d",&num);
	
    printf("cube of the number is : %d",num * num * num);
	return 0;
}