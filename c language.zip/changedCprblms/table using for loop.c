#include <stdio.h>
int main ()
{
	int num;
	printf("Enter a number : ");
	scanf("%d",&num);
	
	for(int i=1; i<=10; i++){
		printf("%dx%d=%d\n",num,i,num*i);
	}
	return 0;
}

//#include <stdio.h>
//int main()
//{
//	int n;
//	printf("Enter a number : ");
//	scanf("%d",&n);
//	
//	for(int i=10; i>=1; i--){
//		printf("%d\n",n*i);
//	}
//}
//

//break word intro
//keep taking numbers until user enters an odd number by do while loop
//#include <stdio.h>
//int main ()
//{
//	int n;
//	do{
//		printf("Enter a number : ");
//		scanf("%d",&n);
//		printf("%d\n",n);
//		
//		if(n % 2 != 0){
//			break;
//		}
//	}while(1);
//	printf("thank u");
//	
//	return 0;
//}


//break var use
//it break the iteration and stops
//keep taking numbers until user enters a num multiple of 7
//#include <stdio.h>
//int main()
//{
//	int a;
//	do{
//		printf("Enter a number : ");
//		scanf("%d",&a);
//		printf("%d\n",a);
//		
//		if(a % 7 == 0){
//			break;
//		}
//	}while(1);
//	printf("stop its the multiple of 7");
//}


//continue var use
//continue used to skip to next iteration
//#include <stdio.h>
//int main ()
//{
//	for(int i=1; i<=5; i++){
//		if(i==3){
//			continue;
//		}
//		printf("%d\n",i);
//	}
//	return 0;
//}