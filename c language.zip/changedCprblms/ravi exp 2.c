#include<stdio.h>
int main()
{
	int a,b;
	printf("enter a number : ");
	scanf("%d%d",&a,&b);
	printf("area of the rectangle : %d",a*b);
	return 0;
}