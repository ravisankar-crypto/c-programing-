/*structures
SYNTAX 
struct student{
char name[100];
int roll;
float cgpa;
};
*/
#include <stdio.h>
#include <string.h>

struct student {
	int roll;
	float cgpa;
	char name[100];	
};

int main()
{
	struct student s1;
	s1.roll = 1664;
	s1.cgpa = 9.2;
//	s1.name = "shaikZaid";
	strcpy(s1.name,"shaikZaid");
	
	printf("Student name = %s\n",s1.name);
	printf("Roll no = %d\n",s1.roll);
	printf("%f\n",s1.cgpa);
	return 0;
}
