#include<stdio.h>
int main()
{
	int a,b,c,sum;
	float d;
	scanf("%d%d%d",&a,&b,&c);
	sum=a+b+c;
	d=sum/3.0;
	printf("%f",d);
	
		return 0;
}