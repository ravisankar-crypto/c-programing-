#include <stdio.h>
#include <string.h>

struct student {
	int roll;
	float cgpa;
	char name[100];
};

int main()
{
	struct student cse[100];
	cse[0].roll = 894;
	cse[0].cgpa = 9.2;
	strcpy(cse[0].name,"Shaik Zaid");
	
	printf("Name : %s\n",cse[0].name);
	printf("Roll no: %d\n",cse[0].roll);
	printf("CGPA : %.2f\n",cse[0].cgpa);
	
}

 