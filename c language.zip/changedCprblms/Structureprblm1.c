#include <stdio.h>
#include <string.h>

struct student {
	int roll;
	float cgpa;
	char name[100];	
};

int main()
{
	struct student s1;
	s1.roll = 1664;
	s1.cgpa = 9.2;
//	s1.name = "shaikZaid";
	strcpy(s1.name,"shaikZaid");
	
	printf("Student name = %s\n",s1.name);
	printf("Roll no = %d\n",s1.roll);
	printf("%f\n",s1.cgpa);
	
	struct student s2;
	s2.roll = 16654;
	s2.cgpa = 9.5;
	strcpy(s2.name,"Vannur Swamy");
	
	printf("Student name = %s\n",s2.name);
	printf("Roll no = %d\n",s2.roll);
	printf("%f\n",s2.cgpa);
	
	struct student s3;
	s3.roll = 1674;
	s3.cgpa = 9.9;
	strcpy(s3.name,"Ravi");
	
	printf("Student name = %s\n",s3.name);
	printf("Roll no = %d\n",s3.roll);
	printf("%f\n",s3.cgpa);
	return 0;
}

