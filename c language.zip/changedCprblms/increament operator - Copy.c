#include <stdio.h>+
int main()
{
	//increament operatot
	//++i(pre increament) 
	//i++(post increament)
	
	int i=1;
//	printf("%d\n",i++); //use,then increase
//	printf("%d\n",i);
	
	printf("%d\n",++i); //increase,then use
	printf("%d\n",i);
	return 0;
}