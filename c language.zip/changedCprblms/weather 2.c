//#include <stdio.h>
//int main()
//{
//	int year;
//	printf("Enter year : ");
//	scanf("%d",&year);
//	
//	if((year % 400 == 0 || year % 4 ==0 && year % 100 != 0)){
//		printf("this year is a leap year : ");
//	}else{
//			printf("this is not a leap year");
//		}
//		return 0;
//	}


#include <stdio.h>;
int main()
{
	int a,b,c;
	printf("Enter three numbers : ");
	scanf("%d%d%d",&a,&b,&c);
	
	if(a >= b && a >= c){
		printf("largest number is : %d",a);
	}else if(b >= a && b >= c){
		printf("largest number is : %d",b);
	}else{
		printf("largest number is : %d",c);
	}
	return 0;
}