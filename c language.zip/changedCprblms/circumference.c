#include <stdio.h>
int main()
{
	int r;
	float circumference;
	scanf("%d",&r);
	circumference = 3.14*2*r;
	printf("Circumference of circle : %f\n",circumference);
	return 0;
}