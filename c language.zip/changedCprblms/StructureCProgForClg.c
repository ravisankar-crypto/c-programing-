#include <stdio.h>
#include <string.h>

typedef struct student {
    int id;
    char name[50];
    float cgpa;
} st;

typedef struct teacher {
    int id;
    char name[50];
    char subject[50];
} te;

typedef struct staff {
    int id;
    char name[50];
    char dept[50];
} sf;

int main() {
    int nStu, nTea, nStf, i;

    printf("Enter number of Students : ");
    scanf("%d", &nStu);
    st s[nStu];
    for (i = 0; i < nStu; i++) {
        printf("\nEnter details of Student %d\n", i + 1);
        printf("ID: ");
        scanf("%d", &s[i].id);
        printf("Name: ");
        scanf(" %[^\n]", s[i].name);
        printf("CGPA: ");
        scanf("%f", &s[i].cgpa);
    }

    printf("\nEnter number of Teachers : ");
    scanf("%d", &nTea);
    te t[nTea];
    for (i = 0; i < nTea; i++) {
        printf("\nEnter details of Teacher %d\n", i + 1);
        printf("ID: ");
        scanf("%d", &t[i].id);
        printf("Name: ");
        scanf(" %[^\n]", t[i].name);
        printf("Subject: ");
        scanf(" %[^\n]", t[i].subject);
    }

    printf("\nEnter number of Staff : ");
    scanf("%d", &nStf);
    sf stf[nStf];
    for (i = 0; i < nStf; i++) {
        printf("\nEnter details of Staff %d\n", i + 1);
        printf("ID: ");
        scanf("%d", &stf[i].id);
        printf("Name: ");
        scanf(" %[^\n]", stf[i].name);
        printf("Department: ");
        scanf(" %[^\n]", stf[i].dept);
    }

    printf("\n===== COLLEGE DATA =====\n");

    printf("\n--- Students ---\n");
    for (i = 0; i < nStu; i++)
        printf("ID: %d | Name: %s | CGPA: %.2f\n", s[i].id, s[i].name, s[i].cgpa);

    printf("\n--- Teachers ---\n");
    for (i = 0; i < nTea; i++)
        printf("ID: %d | Name: %s | Subject: %s\n", t[i].id, t[i].name, t[i].subject);

    printf("\n--- Staff ---\n");
    for (i = 0; i < nStf; i++)
        printf("ID: %d | Name: %s | Department: %s\n", stf[i].id, stf[i].name, stf[i].dept);

    return 0;
}
