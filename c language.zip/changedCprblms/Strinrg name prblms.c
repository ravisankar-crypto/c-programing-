//#include <stdio.h>
//int main()
//{
//	char name[50];
//	scanf("%s",name);
//	printf("Your name is %s",name);
//	return 0;
//}

#include <stdio.h>
int main()
{
	char fullname[50];
	scanf("%s",fullname);
	printf("Your full name is : %s",fullname);
	return 0;
}