#include <stdio.h>
int main()
{
	int a;
	printf("Enter a number: ");
	scanf("%d",&a);
	
	printf("cube of the number is: %d",a*a*a*a);
	return 0;
}