#include<stdio.h>
int main()
{
	int n;
	scanf("%d",&n);
	int a[n];
	for(int i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
	for(int i=0;i<n;i++){
		if(a[i]%2==0){
			printf("%d is even",a[i]);
		}else{
			printf("%d is odd",a[i]);
		}
	}
	return 0;
}