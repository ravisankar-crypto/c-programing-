#include <stdio.h>
int main(){
	char a [10];
	printf("Eenter ur name : ");
	scanf("%s",&a);
	printf("Hi my name is : %s",a);
	return 0;
}