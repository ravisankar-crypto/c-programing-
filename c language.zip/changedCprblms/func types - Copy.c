//Function types two types
//1.library function-->small func inbuilt in c like scanf(),printf(),....etc
//2.user defined -->declared & defined by progrmmer

//PASSING ARGUMENTS
//func can take value and give some value
//         (parameter)          (return value)
//		 
//		 void printHello();
//		 void printTable(int n);
//		 int sum(int a,int b);  