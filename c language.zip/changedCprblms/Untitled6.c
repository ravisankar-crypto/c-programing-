#include <stdio.h>
int main ()

int sum(int a,int b);

{
	int a,b;
	printf("Enter first number : ");
	scanf("%d";&a);
	printf("Enter second number : ");
	scanf("%d";&b);
	
	int s = sum(a,b);
	printf("sum is %d:",s);
	return 0;
}

int sum(int X,int Y){
	return X + Y;
}