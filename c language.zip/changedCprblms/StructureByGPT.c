//Define and Display a Structure
//#include <stdio.h>
//
//struct student {
//	char name[50];
//	int age;
//	float marks; 
//};
//
//int main()
//{
//	struct student s = {"zaid",18,96.1};
//	printf("Name: %s\nAge: %d\nMarks: %.2f\n",s.name,s.age,s.marks);
//	
//	return 0;
//}


//Input and Display a Structure
#include <stdio.h>

struct student{
	char name[30];
	int rollNo;
	float marks;
};

int main()
{
	struct student s;
	printf("Enter name,roll no and marks: ");
	scanf("%s %d %f",s.name,&s.rollNo,&s.marks);
	printf("\nSTUDENT DETAILS:\n");
	printf("Name: %s\nRoll No: %d\nMarks: %.2f\n",s.name,s.rollNo,s.marks);
	return 0;
}