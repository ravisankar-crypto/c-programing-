#include <stdio.h>
int main()
{
	int a,b;
	scanf("%d%d",&a,&b);
	printf("Sum is : %d\nSub : %d\nPro : %d\nDiv : %f",a+b,a-b,a*b,a/b);
	return 0;
}