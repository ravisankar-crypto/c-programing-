//#include <stdio.h>
//struct stu {
//	char name[30];
//	int rollNo;
//	char branch[30];
//};
//int main()
//{
//	struct stu s1;
//	printf("Enter name, rollNo, branch: ");
//	scanf("%s %d %s",s1.name,&s1.rollNo,s1.branch);
//	printf("\nStudent Details:\n");
//	printf("Name: %s\nRoll No: %d\nBranch: %s",s1.name,s1.rollNo,s1.branch);
//	return 0;
//}

#include <stdio.h>

struct Book {
    char title[50];
    char author[50];
    float price;
};

int main() {
    struct Book b[3];
    for (int i = 0; i < 3; i++) {
        printf("Enter title, author and price for book %d: ", i + 1);
        scanf("%s %s %f", b[i].title, b[i].author, &b[i].price);
    }

    printf("\nBooks List:\n");
    for (int i = 0; i < 3; i++)
        printf("%s by %s - ?%.2f\n", b[i].title, b[i].author, b[i].price);

    return 0;
}
