
//#include <stdio.h>
//int main()
//{
//	 for(initialisation;conditon;updation){
//	 do something here
//	 }
//	//i=iterator 0r a counter
//	//can also be used for float,char...etc
//	for(int i=1; i<=100; i=i+1){
//		printf("%d\n",i);
// 	}
// 	
// 	for(int i=10; i>=1; i=i-1){
// 		printf("%d\n",i);
//	 }
//	 
//	for(int i=0; i<=10; i=i+1){
//		printf("%d\n",i);
//	}
//	return 0;
//}


//char and float too
//#include <stdio.h>
//int main()
//{
//	for(float i=1; i<=5; i++){
//		printf("%f\n",i);
//	}
//	
//	for(char ch='a'; ch<='z'; ch++){
//		printf("%c\n",ch);
//	}
//	return 0;
//}


#include <stdio.h>
int main()
{
	int n;
	printf("Enter a number : ");
	scanf("%d",&n);
	
	for(int i=0; i<=n; i++){
		printf("%d\n",i);
	}
	return 0;
}

//#include <stdio.h>
//int main()
//{
//	for(float i=1; i<=5; i++){
//		printf("%f\n",i);
//	}
//	
//	for(char ch='a'; ch<='z'; ch++){
//		printf("%c\n",ch);
//	}
//	return 0;
//}
