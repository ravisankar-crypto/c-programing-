#include <stdio.h>
#include <string.h>

typedef struct bankAcc{
	int accNo;
	char name[100];
}acc;

int main()
{
	int n,i;
	printf("No of acc entries : ");
	scanf("%d",&n);
	
	acc s[n];
	
	for(i=0;i<n;i++){
		printf("Enter details of bank acc %d: \n",i+1);
		printf("Account Number : ");
		scanf("%d",&s[i].accNo);
		printf("Enter Your Name : ");
		scanf(" %[^\n]",s[i].name);
	}
	
	printf("\n------BANK ACC DETAILS------\n");
	for(i=0;i<n;i++){
		printf("Bank acc no %d:\n",i+1);
		printf("Account Number: %d\n",s[i].accNo);
		printf("Account holder Name : %s\n",s[i].name);
	}
	return 0;
}