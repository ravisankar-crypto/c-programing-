#include <stdio.h>
#include <string.h>
int main ()
{
	char weather[10];
	printf("Enter the weather : ");
	scanf("%s",&weather);
	
	if(strcmp(weather, "sunny") == 0){
		printf("can play cricket");
	}else{
		printf("play indoor games");
	}
	return 0;
}