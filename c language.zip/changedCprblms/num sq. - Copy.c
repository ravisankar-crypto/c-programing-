#include <stdio.h>
int main()
{
	int side;
	printf("Enter side: ");
	scanf("%d", &side);
	
	printf("area is : %d",side * side);
	return 0;
}